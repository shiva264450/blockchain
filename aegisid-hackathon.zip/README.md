# AegisID — Blockchain Identity Demo

A beginner-friendly hackathon starter using:
- React + Vite for the web UI
- ethers.js for wallet / contract interaction
- Solidity for on-chain identity commitments
- Polygon Amoy testnet (chain ID `80002`, token symbol `POL`)

**Important:** This is a learning prototype, not a production identity system. It stores a random commitment and verification status, not real identity documents. A real deployment needs a reviewed privacy model, issuer governance, recovery/revocation, audited contracts, and standards-based verifiable credentials.

## How the demo works
1. Connect MetaMask to Polygon Amoy.
2. Register a random identity commitment from your wallet.
3. The contract deployer is the initial issuer and can verify registrations.
4. Check the wallet's status in the dashboard.

There is no separate API server in this MVP: the smart contract is the backend/state layer. Never put names, Aadhaar numbers, phone numbers, document scans, or passwords on-chain.

## Requirements
- Node.js 20+ recommended for the Vite app
- npm
- MetaMask (or another injected EVM wallet)
- Test POL on Polygon Amoy

## 1. Install frontend
```bash
cd frontend
npm install
cp .env.example .env
npm run dev
```
Open the local URL printed by Vite.

## 2. Deploy the contract
For the easiest beginner workflow, use [Remix](https://remix.ethereum.org/):
1. Open `contracts/AegisID.sol` in Remix by creating a file and pasting its contents.
2. Compile with Solidity `0.8.24`.
3. In Deploy & Run, choose **Injected Provider - MetaMask** and switch MetaMask to Polygon Amoy.
4. Deploy and confirm the transaction. The deploying wallet becomes the owner and initial issuer.
5. Copy the deployed contract address.

In `frontend/.env`, set:
```env
VITE_CONTRACT_ADDRESS=0xYOUR_DEPLOYED_CONTRACT_ADDRESS
```
Restart Vite after changing `.env`.

Amoy network details:
- Network name: Polygon Amoy Testnet
- Chain ID: `80002`
- Currency symbol: `POL`
- Explorer: `https://amoy.polygonscan.com/`

Use Polygon's official documentation to select a currently supported RPC if you configure a custom RPC. Public RPC endpoints can change; the app itself uses MetaMask's provider for transactions.

## 3. Demo flow
1. Connect the deployer wallet in MetaMask on Amoy.
2. Click **Register demo identity**. The app generates a random commitment and sends it to the contract.
3. Click **Refresh status** to see that the identity is registered but unverified.
4. Click **Verify identity (issuer)** using the deployer/issuer wallet.
5. Refresh status; it should show **Verified**.
6. For a user wallet, connect a different wallet and register a separate identity. The issuer wallet can verify it.

### Why a random commitment?
This demo intentionally does not collect personal information. The random value is only a placeholder for an identity commitment. It does not prove that a real-world identity is authentic.

## Security checklist
- Never use real personal data in this demo.
- Never paste a wallet seed phrase or private key into a website or source file.
- Use testnet tokens only; do not fund a hackathon demo with real assets.
- Anyone can read public chain state. Hashes are not automatically private; predictable values can be guessed.
- The demo issuer is the deployer. Production issuer authorization should use governance, multi-signature controls, and monitoring.
- The owner can authorize issuers; secure that account carefully.
- No identity revocation, key recovery, credential expiry, rate limiting, formal audit, or zero-knowledge proofs are included.
- Test locally and get an experienced reviewer before any real-world deployment.

## Troubleshooting
- **Contract address missing:** set `VITE_CONTRACT_ADDRESS` in `frontend/.env`, then restart Vite.
- **Wrong network:** switch MetaMask to Polygon Amoy (chain ID `80002`).
- **Insufficient funds:** obtain test POL from an official/community-supported Amoy faucet; faucet availability can change.
- **Issuer-only error:** verification must be sent from the deployer wallet or another address authorized by the owner.
- **MetaMask not found:** open the app in a browser with an EVM wallet extension installed.

## Project structure
```text
aegisid-hackathon/
├── contracts/AegisID.sol
├── frontend/
│   ├── src/App.jsx
│   ├── src/main.jsx
│   ├── src/style.css
│   ├── .env.example
│   └── package.json
└── README.md
```
