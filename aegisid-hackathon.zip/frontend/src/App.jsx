import { useCallback, useState } from 'react';
import { BrowserProvider, Contract, hexlify, randomBytes } from 'ethers';

const CONTRACT_ADDRESS = import.meta.env.VITE_CONTRACT_ADDRESS || '';
const AMOY_CHAIN_ID = '0x13882'; // 80002
const EXPLORER = 'https://amoy.polygonscan.com';

const ABI = [
  'function owner() view returns (address)',
  'function issuers(address) view returns (bool)',
  'function registerIdentity(bytes32 commitment)',
  'function verifyIdentity(address user)',
  'function checkIdentity(address user) view returns (bool registered, bool verified, bytes32 commitment)',
];

function short(address) {
  return address ? `${address.slice(0, 6)}…${address.slice(-4)}` : 'Not connected';
}

export default function App() {
  const [account, setAccount] = useState('');
  const [provider, setProvider] = useState(null);
  const [contract, setContract] = useState(null);
  const [identity, setIdentity] = useState(null);
  const [issuer, setIssuer] = useState(false);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState('Connect your wallet to begin.');
  const [txHash, setTxHash] = useState('');

  const connect = useCallback(async () => {
    try {
      setNotice('');
      if (!window.ethereum) {
        setNotice('No EVM wallet found. Install MetaMask and reopen this page.');
        return;
      }
      if (!/^0x[a-fA-F0-9]{40}$/.test(CONTRACT_ADDRESS)) {
        setNotice('Set VITE_CONTRACT_ADDRESS in frontend/.env after deploying the contract, then restart the app.');
        return;
      }
      const p = new BrowserProvider(window.ethereum);
      await p.send('eth_requestAccounts', []);
      const network = await p.getNetwork();
      if (network.chainId !== 80002n) {
        try {
          await window.ethereum.request({
            method: 'wallet_switchEthereumChain',
            params: [{ chainId: AMOY_CHAIN_ID }],
          });
        } catch (switchError) {
          setNotice('Please add Polygon Amoy (chain ID 80002, currency POL) to your wallet and switch to it.');
          return;
        }
      }
      const signer = await p.getSigner();
      const address = await signer.getAddress();
      const c = new Contract(CONTRACT_ADDRESS, ABI, signer);
      setProvider(p);
      setContract(c);
      setAccount(address);
      setIssuer(await c.issuers(address));
      setNotice('Wallet connected. Refresh status to load your identity.');
    } catch (e) {
      setNotice(e.shortMessage || e.message || 'Wallet connection failed.');
    }
  }, []);

  const refresh = useCallback(async () => {
    if (!contract || !account) return;
    try {
      setBusy(true);
      const result = await contract.checkIdentity(account);
      setIdentity({
        registered: result[0],
        verified: result[1],
        commitment: result[2],
      });
      setIssuer(await contract.issuers(account));
      setNotice('Identity status refreshed from Polygon Amoy.');
    } catch (e) {
      setNotice(e.shortMessage || e.message || 'Could not read contract status.');
    } finally {
      setBusy(false);
    }
  }, [contract, account]);

  const register = async () => {
    if (!contract) return;
    try {
      setBusy(true); setNotice('Waiting for wallet confirmation…'); setTxHash('');
      // Random demo commitment; no name, document number, or other PII is collected.
      const commitment = hexlify(randomBytes(32));
      const tx = await contract.registerIdentity(commitment);
      setTxHash(tx.hash);
      setNotice('Registration transaction sent. Waiting for confirmation…');
      await tx.wait();
      setNotice('Registration complete. Refresh status to view it.');
      await refresh();
    } catch (e) {
      setNotice(e.shortMessage || e.reason || e.message || 'Registration failed.');
    } finally {
      setBusy(false);
    }
  };

  const verify = async () => {
    if (!contract || !account) return;
    try {
      setBusy(true); setNotice('Confirm verification in your wallet…'); setTxHash('');
      const tx = await contract.verifyIdentity(account);
      setTxHash(tx.hash);
      setNotice('Verification transaction sent. Waiting for confirmation…');
      await tx.wait();
      setNotice('Identity verified on-chain.');
      await refresh();
    } catch (e) {
      setNotice(e.reason || e.shortMessage || e.message || 'Verification failed. Are you using an authorized issuer wallet?');
    } finally {
      setBusy(false);
    }
  };

  const disconnect = () => {
    setAccount(''); setProvider(null); setContract(null); setIdentity(null); setIssuer(false); setTxHash('');
    setNotice('Disconnected in this app. You may also disconnect the site from your wallet settings.');
  };

  return (
    <main className="page">
      <nav className="nav">
        <div className="brand"><div className="brand-mark">A</div><span>Aegis<span className="accent">ID</span></span></div>
        <div className="network"><span className="pulse" /> Polygon Amoy <span className="chain">TESTNET</span></div>
      </nav>

      <section className="hero">
        <div className="eyebrow"><span>●</span> DECENTRALIZED IDENTITY PROTOCOL</div>
        <h1>Your identity.<br /><span className="gradient">Your control.</span></h1>
        <p className="lead">A simple blockchain identity demo built around user-controlled wallets, on-chain verification status, and data minimization.</p>
        <div className="hero-actions">
          {!account
            ? <button className="primary" onClick={connect}>Connect wallet <span>↗</span></button>
            : <button className="primary" onClick={disconnect}>Disconnect {short(account)}</button>}
          <a className="secondary" href={`${EXPLORER}`} target="_blank" rel="noreferrer">Explore Amoy ↗</a>
        </div>
        <div className="trust-row"><span>✓ No documents stored on-chain</span><span>✓ Wallet-based access</span><span>✓ Testnet demo</span></div>
      </section>

      <section className="dashboard">
        <div className="section-heading"><div><div className="eyebrow">IDENTITY CONSOLE</div><h2>Your dashboard</h2></div><button className="outline" onClick={refresh} disabled={!contract || busy}>↻ Refresh status</button></div>
        <div className="cards">
          <article className="panel identity-panel">
            <div className="panel-top"><span className="panel-icon">◈</span><span className="muted-label">WALLET IDENTITY</span><span className={`status ${identity?.verified ? 'verified' : identity?.registered ? 'pending' : ''}`}>{identity?.verified ? 'Verified' : identity?.registered ? 'Pending' : 'Not registered'}</span></div>
            <div className="wallet-address">{short(account)}</div>
            <p className="muted">{account || 'Connect your wallet to load your identity.'}</p>
            <div className="divider" />
            <div className="metric-row"><span>Registration</span><strong>{identity?.registered ? 'Complete' : 'Not started'}</strong></div>
            <div className="metric-row"><span>Verification</span><strong>{identity?.verified ? 'Verified on-chain' : 'Awaiting issuer'}</strong></div>
            <button className="primary full" disabled={!contract || busy || !!identity?.registered} onClick={register}>{busy ? 'Please wait…' : '＋ Register demo identity'}</button>
            {identity?.registered && <button className="outline full" disabled={!contract || busy || identity?.verified || !issuer} onClick={verify}>✓ Verify identity (issuer)</button>}
            {identity?.registered && !issuer && !identity?.verified && <p className="hint">Only an authorized issuer can verify this wallet. Connect the deployer/issuer wallet to verify it.</p>}
          </article>

          <article className="panel detail-panel">
            <div className="panel-top"><span className="panel-icon purple">⌘</span><span className="muted-label">ON-CHAIN RECORD</span></div>
            <h3>Privacy by design</h3>
            <p className="muted">The contract stores a random 32-byte commitment and two status flags. It does not collect or store your name or documents.</p>
            <div className="divider" />
            <div className="metric-row"><span>Network</span><strong>Polygon Amoy</strong></div>
            <div className="metric-row"><span>Chain ID</span><strong>80002</strong></div>
            <div className="metric-row"><span>Issuer role</span><strong>{issuer ? 'Authorized' : 'User'}</strong></div>
            <div className="metric-row"><span>Contract</span><strong>{CONTRACT_ADDRESS ? short(CONTRACT_ADDRESS) : 'Not configured'}</strong></div>
            {CONTRACT_ADDRESS && /^0x[a-fA-F0-9]{40}$/.test(CONTRACT_ADDRESS) && <a className="explorer-link" href={`${EXPLORER}/address/${CONTRACT_ADDRESS}`} target="_blank" rel="noreferrer">View contract on explorer ↗</a>}
          </article>
        </div>
        {identity?.commitment && identity.registered && <article className="panel commitment">
          <div className="muted-label">IDENTITY COMMITMENT</div>
          <code>{identity.commitment}</code>
          <p className="hint">This is a demo commitment, not a real-world identity credential.</p>
        </article>}
        {txHash && <div className="tx"><span>Transaction submitted</span><a href={`${EXPLORER}/tx/${txHash}`} target="_blank" rel="noreferrer">{short(txHash)} — view on AmoyScan ↗</a></div>}
        {notice && <div className="notice"><span>ⓘ</span><p>{notice}</p></div>}
      </section>

      <section className="steps">
        <div className="eyebrow">HOW IT WORKS</div><h2>Three steps. One verifiable status.</h2>
        <div className="step-grid">
          <div className="step"><span>01</span><h3>Connect</h3><p>Connect an EVM wallet on Polygon Amoy.</p></div>
          <div className="step"><span>02</span><h3>Register</h3><p>Create a random commitment and record it on-chain.</p></div>
          <div className="step"><span>03</span><h3>Verify</h3><p>An authorized issuer confirms the wallet's status.</p></div>
        </div>
      </section>
      <footer><div className="brand"><div className="brand-mark">A</div><span>Aegis<span className="accent">ID</span></span></div><p>Hackathon prototype · Not for real identity verification</p><a href="https://amoy.polygonscan.com/" target="_blank" rel="noreferrer">Polygon Amoy Explorer ↗</a></footer>
    </main>
  );
}
